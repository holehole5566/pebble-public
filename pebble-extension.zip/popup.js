const API = 'https://pebble.pe4nut.com/api/v1';

const $ = (s) => document.getElementById(s);
let currentUrl = '';
let tags = [];
let selectedTags = [];
let previewData = null;

document.addEventListener('DOMContentLoaded', async () => {
  // Bind events
  $('save-btn').addEventListener('click', save);
  $('logout-btn').addEventListener('click', logout);
  $('link-btn').addEventListener('click', linkWithCode);
  $('preview-btn').addEventListener('click', () => {
    const url = $('url-input').value.trim();
    if (url) { currentUrl = url; loadPreview(url); }
  });

  // Check existing session
  const { accessToken, user } = await chrome.storage.local.get(['accessToken', 'user']);
  if (accessToken && user) {
    await showSaveView(user);
  } else {
    $('login-view').style.display = '';
  }
});

// ── Save View ──
async function showSaveView(user) {
  $('login-view').style.display = 'none';
  $('no-account-view').style.display = 'none';
  $('user-bar').style.display = 'flex';
  $('save-view').style.display = 'block';

  $('user-avatar').textContent = (user.nickname || user.email || '?')[0];
  $('user-name').textContent = user.nickname || user.email;

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  currentUrl = tab?.url || '';
  $('url-input').value = currentUrl;

  loadTags();
  if (currentUrl && currentUrl.startsWith('http')) loadPreview(currentUrl);
}

// ── API helper with auto-refresh ──
async function api(path, opts = {}) {
  let { accessToken } = await chrome.storage.local.get('accessToken');

  let res = await fetch(`${API}${path}`, {
    ...opts,
    headers: { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json', ...opts.headers },
  });

  if (res.status === 401) {
    accessToken = await chrome.runtime.sendMessage({ type: 'refresh' });
    if (!accessToken) {
      await chrome.storage.local.clear();
      location.reload();
      return null;
    }
    res = await fetch(`${API}${path}`, {
      ...opts,
      headers: { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json', ...opts.headers },
    });
  }
  return res;
}

// ── Tags ──
async function loadTags() {
  try {
    const res = await api('/tags?group=saved');
    if (!res || !res.ok) return;
    const data = await res.json();
    tags = data.tags || [];
    renderTags();
  } catch {}
}

function renderTags() {
  const wrap = $('tags-wrap');
  wrap.innerHTML = '';
  if (!tags.length) {
    wrap.innerHTML = '<span style="font-size:12px;color:#888">標籤分類請在 App 設定</span>';
    return;
  }
  tags.forEach((t) => {
    const chip = document.createElement('div');
    chip.className = 'tag-chip';
    chip.textContent = t.name;
    chip.addEventListener('click', () => {
      const idx = selectedTags.indexOf(t.name);
      if (idx >= 0) selectedTags.splice(idx, 1);
      else selectedTags.push(t.name);
      chip.classList.toggle('on');
    });
    wrap.appendChild(chip);
  });
  const hint = document.createElement('span');
  hint.style.cssText = 'font-size:11px;color:#888;width:100%;display:block;margin-top:6px';
  hint.textContent = '新增或管理標籤請在 App 設定';
  wrap.appendChild(hint);
}

// ── Preview ──
async function loadPreview(url) {
  $('preview-loading').style.display = '';
  try {
    const res = await api('/metadata/extract', {
      method: 'POST',
      body: JSON.stringify({ url }),
    });
    if (!res || !res.ok) { $('preview-loading').style.display = 'none'; return; }
    previewData = await res.json();
    $('preview-loading').style.display = 'none';
    $('preview').style.display = '';
    if (previewData.thumbnailUrl) {
      const img = $('preview-img');
      img.onerror = () => img.style.display = 'none';
      img.src = previewData.thumbnailUrl;
      img.style.display = 'block';
    }
    $('preview-user').textContent = previewData.username || previewData.platform || '';
    $('preview-caption').textContent = previewData.caption || '';
  } catch {
    $('preview-loading').style.display = 'none';
  }
}

// ── Save ──
async function save() {
  const btn = $('save-btn');
  const result = $('result');
  currentUrl = $('url-input').value.trim();
  if (!currentUrl) return;

  btn.disabled = true;
  btn.textContent = '儲存中...';
  result.textContent = '';

  try {
    const res = await api('/saved', {
      method: 'POST',
      body: JSON.stringify({
        originalUrl: currentUrl,
        personalNote: $('note-input').value.trim(),
        tags: selectedTags,
      }),
    });

    if (res && res.ok) {
      result.className = 'result ok';
      result.textContent = '✓ 已儲存到 Pebble！';
      btn.textContent = '已儲存 ✓';
    } else {
      const err = res ? await res.text() : '';
      if (res && res.status === 403 && err.includes('saved_limit_reached')) {
        throw new Error('已達收藏上限（50 則），升級 Premium 解鎖無限收藏');
      }
      throw new Error('儲存失敗');
    }
  } catch (e) {
    result.className = 'result err';
    result.textContent = e.message || '儲存失敗';
    btn.disabled = false;
    btn.textContent = '儲存到 Pebble';
  }
}

// ── Link with Code ──
async function linkWithCode() {
  const code = $('link-code').value.trim();
  const result = $('link-result');
  if (code.length !== 6) {
    result.className = 'result err';
    result.textContent = '請輸入 6 位數登入碼';
    return;
  }

  $('link-btn').disabled = true;
  result.textContent = '';

  try {
    const res = await fetch(`${API}/auth/link/verify`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code }),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || '登入碼無效或已過期');
    }

    const data = await res.json();
    await chrome.storage.local.set({
      accessToken: data.accessToken,
      refreshToken: data.refreshToken,
      user: data.user,
    });
    await showSaveView(data.user);
  } catch (e) {
    result.className = 'result err';
    result.textContent = e.message || '連結失敗';
    $('link-btn').disabled = false;
  }
}

// ── Logout ──
async function logout() {
  const { refreshToken: rt } = await chrome.storage.local.get('refreshToken');
  if (rt) api('/auth/logout', { method: 'POST', body: JSON.stringify({ refreshToken: rt }) }).catch(() => {});
  await chrome.storage.local.clear();
  location.reload();
}

const API_BASE = 'https://pebble.pe4nut.com/api/v1';

// Token refresh logic in background
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'refresh') {
    refreshToken().then(sendResponse);
    return true; // async
  }
});

async function refreshToken() {
  const { refreshToken: rt } = await chrome.storage.local.get('refreshToken');
  if (!rt) return null;
  try {
    const res = await fetch(`${API_BASE}/auth/refresh`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refreshToken: rt }),
    });
    if (!res.ok) {
      await chrome.storage.local.remove(['accessToken', 'refreshToken']);
      return null;
    }
    const data = await res.json();
    await chrome.storage.local.set({
      accessToken: data.accessToken,
      refreshToken: data.refreshToken,
    });
    return data.accessToken;
  } catch {
    return null;
  }
}
